project name: OPEN-ED-REV.B
pcb thickness 1.5mm
gold plated pads
